/*=============================================================================
  Copyright (C) 2013-2025 Allied Vision Technologies.  All Rights Reserved.
  Subject to the BSD 3-Clause License.
=============================================================================*/

#include "SynchronousGrab.h"

#include <iostream>
#include <exception>
#include <memory>

int main(int argc, char* argv[])
{
    std::cout << "\n";
    std::cout << "///////////////////////////////////////\n";
    std::cout << "/// VmbCPP Synchronous Grab Example ///\n";
    std::cout << "///////////////////////////////////////\n\n";

    try
    {
        std::unique_ptr<VmbCPP::Examples::SynchronousGrab> acquisitionHelper;

        if (argc > 2)
        {
            std::cout << "Usage: " << argv[0] << " [CameraID]\n\n";
            std::cout << "Parameters:   CameraID    ID of the camera to use (using first camera if not specified)\n";
        }
        else if (argc == 2)
        {
            acquisitionHelper.reset(new VmbCPP::Examples::SynchronousGrab(argv[1]));
        }
        else
        {
            acquisitionHelper.reset(new VmbCPP::Examples::SynchronousGrab());
        }

        acquisitionHelper->AcquireImage();
    }
    catch (std::runtime_error& e)
    {
        std::cout << e.what() << std::endl;
    }    

    std::cout << std::endl;
}

