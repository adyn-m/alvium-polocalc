VmbCPP Examples
===============

Beta Disclaimer
---------------
THE SOFTWARE IS PRELIMINARY AND STILL IN TESTING AND VERIFICATION PHASE AND IS PROVIDED ON AN �AS IS� AND �AS AVAILABLE� BASIS AND IS BELIEVED TO CONTAIN DEFECTS. A PRIMARY PURPOSE OF THIS EARLY ACCESS IS TO OBTAIN FEEDBACK ON PERFORMANCE AND THE IDENTIFICATION OF DEFECT SOFTWARE, HARDWARE AND DOCUMENTATION.

Compile instructions & tool chain requirements
----------------------------------------------

### Requirements
* cmake (>= 3.21)
* VmbAPI Installation directory incl. `FindVmb.cmake` (VmbC, VmbCPP, VmbImageTransform)
* Qt (5.15.x)
* Linux: gcc/g++ (>= 8.4.0)
* Windows: Microsoft Visual Studio (>= 2017)
* macOS: XCode (>= 11.7)
* OpenCV (>= 4.12)\
  required for the OpenCVBridge example only. If OpenCV is not available this example will be skipped in the configuration.\
  For Linux install `libopencv-dev` package.\
  For Windows an installer and source packages are available for download.\
  For macOS building from source is recommended.

### 1. Setting Dependency Locations
Before running CMake to initialize the project, you need to copy and adjust `CMakeUserPresets.json` from `CMakeUserPresets.json.TEMPLATE`.

Depending on your desired configuration and platform, you need to specify the path to your VmbAPI, Qt and OpenCV installation directory.

Open the file in an editor and adjust the following variables according to your local setup as follows:

#### Windows
* VmbAPI:

    In the configurePreset `win64`, set the value of `VMB_API_PATH` to your local VmbAPI installation.
    The path must point to the root directory of your VmbAPI installation.
    The VmbAPI installation may either be a local directory built with VmbAPI's CMake install target or it may be the API directory of the Vimba X installer, e.g.:

    ```
    "VMB_API_PATH": "C:/Program Files/Allied Vision/Vimba X/api/"
    ```
    
    As an alternative approach you also can choose to set the path directly as CMake cache variable `Vmb_DIR`.


* Qt:

    In addtion, you need to set the Qt search path:

    In the configurePreset `win64`, set the value of `QT_PATH` to your local Qt installation, e.g. `C:/Qt_5_15_x64_Windows` or `"C:/Qt/5.15.2/msvc2019_64"` (depending on whether you are using a self-compiled version of Qt or the official Qt installer):

    ```
    "QT_PATH": "C:/Qt_new/5.15.2/msvc2019_64"
    ```

    As an alternative approach you also can choose to set the path directly as CMake cache variable `Qt5_DIR`.

* OpenCV:
    Configure the path to OpenCV by setting the CMake cache variable `OpenCV_DIR`.
 
     ```CMakeUserPresets.json
      "cacheVariables": {
        "Vmb_DIR":  { "type": "PATH", "value": "C:\\Program Files\\Allied Vision\\VimbaX\\api\\lib\\cmake\\vmb"},
        "OpenCV_DIR": { "type": "PATH", "value": "C:\\SDK\\opencv-4.12\\x64-Release"}
      },
    ```

#### Linux
Similar to Windows, adjust `VMB_API_PATH` for VmbAPI and `QT_PATH` for Qt for your desired Linux configuration:
* `linux64` (will be inherited by `linux64-debug`)
* `arm64` (will be inherited by `arm64-debug`)

If you have installed OpenCV to your system there is no need to specify its location explicitly. CMake will find it automatically.
If you prefer to use a custom build of OpenCV instead configure its location by setting the `OpenCV_DIR` CMake cache variable as 
described in the Windows section.

#### macOS
If you have installed the dependencies as framework packages to your system no additional configuration is required.
To set custom paths to the libraries set the CMake cache variables:
```CMakeUserPresets.json
      "cacheVariables": {
        "OpenCV_DIR":  { "type": "PATH", "value": "/Users/usr/opencv/build_opencv" }
      },
```

### 2. Configuration  
Run CMake with your desired configuration preset to create your build system project files.

```$ cmake --preset <PRESET>```

e.g.: ```$ cmake --preset win64```

>*All available presets can be listed with:*\
>```$ cmake --list-presets```

### 3. Compilation
#### Windows
The configuration step will create a Visual Studio Solution `VmbCExamples.sln` in the folder specified in the configurePreset `win64`, the default is `build-win64`.

#### Linux
Makefiles will be created in the specified build folder, e.g. `build-linux64`

#### macOS
XCode project files will be created in the specified build folder.

#### All platforms
Use the CMake build presets to build a default set of targets for your configuration preset.

```$ cmake --build --preset <PRESET>```

e.g.: ```$ cmake --build --preset win64```

You can adjust the build preset in `CMakeUserPresets.json` to your needs.
