/*=============================================================================
  Copyright (C) 2012-2025 Allied Vision Technologies.  All Rights Reserved.
  Subject to the BSD 3-Clause License.
=============================================================================*/

#include "AcquisitionHelper.h"

#include <exception>
#include <iostream>

int main(int argc, char* argv[])
{
    std::cout << "////////////////////////////////////" << std::endl;
    std::cout << "/// VmbCPP OpenCV Bridge Example ///" << std::endl;
    std::cout << "////////////////////////////////////" << std::endl << std::endl;

    try
    {
        if (argc > 2)
        {
            std::cout << "Usage: " << argv[0] << " [CameraID]" << std::endl << std::endl;
            std::cout << "Parameters:   CameraID    ID of the camera to use (using first camera if not specified)" << std::endl;
        }
        else if (argc == 2)
        {
            VmbCPP::Examples::AcquisitionHelper(argv[1]).Run();
        }
        else
        {
            VmbCPP::Examples::AcquisitionHelper().Run();
        }


    }
    catch (const std::runtime_error& e)
    {
        std::cout << e.what() << std::endl;
        return 1;
    }

    return 0;
    // AcquisitionHelper's destructor will stop the acquisition and shutdown the VmbCPP API
}
