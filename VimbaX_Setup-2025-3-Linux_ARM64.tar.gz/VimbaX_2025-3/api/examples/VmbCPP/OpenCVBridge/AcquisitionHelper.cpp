/*=============================================================================
  Copyright (C) 2012-2025 Allied Vision Technologies. All Rights Reserved.
  Subject to the BSD 3-Clause License.
=============================================================================*/

#include "AcquisitionHelper.h"

#include <VmbCPP/VmbCPP.h>
#include <VmbCPP/thirdparty/OpenCV.hpp>

#include <atomic>
#include <cassert>
#include <condition_variable>
#include <exception>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>

#include <opencv2/highgui.hpp>


namespace VmbCPP {
namespace Examples {

/**
 * \brief Class to process and display OpenCV frames in a separate thread
 */
class OpenCvThread
{
public:
    OpenCvThread(const std::string& windowName, CameraPtr& camera) :
        m_windowName(windowName),
        m_displayThread(&OpenCvThread::ThreadFunction, this),
        m_pCamera(camera)
    {}
    void Run()
    {
        // Wait for thread to finish
        assert (m_displayThread.joinable());
        m_displayThread.join();
    }
    void DisplayFrame(const FramePtr& frame)
    {
        assert(frame);
        std::lock_guard<std::mutex> lock(m_mutex);
        m_frameQueue.push(frame);
        m_condition.notify_one();
    }

private:
    void ThreadFunction()
    {
        std::unique_lock<std::mutex> lock(m_mutex);

        bool running = true;

        cv::Mat cvImage;
        while (running)
        {
            m_condition.wait(lock, [this] { return !m_frameQueue.empty(); });

            while (running && !m_frameQueue.empty())
            {
                FramePtr frame = m_frameQueue.front();
                m_frameQueue.pop();
                lock.unlock();

                const VmbErrorType err = VmbFrameToMat(frame, cvImage);
                if (err != VmbErrorSuccess)
                {
                    std::cerr << "Error in conversion of VmbFrame to OpenCV matrix, err=" + std::to_string(err) << std::endl;
                }
                else
                {
#ifdef _DEBUG
                    // Prove that VmbFrameToMat() did not involve any additional memcpy()
                    VmbUchar_t* imageData = nullptr;
                    assert(frame->GetImage(imageData) == VmbErrorType::VmbErrorSuccess
                        && imageData != nullptr
                        && imageData == cvImage.data
                        && "Wrong OpenCV image data pointer");
#endif

                    std::cout << "." << std::flush;
                    cv::imshow(m_windowName, cvImage);
                    if (cv::waitKey(1) !=  -1) // Process OpenCV events
                    {
                        running = false;
                        break;
                    }
                }
                m_pCamera->QueueFrame(frame);

                lock.lock();
            }
        }

        // Clean up OpenCV window
        cv::destroyWindow(m_windowName);
    }

    const std::string m_windowName;
    std::thread m_displayThread;
    std::mutex m_mutex;
    std::condition_variable m_condition;
    std::queue<FramePtr> m_frameQueue;
    CameraPtr m_pCamera;
};

/**
 * \brief IFrameObserver implementation for asynchronous image acquisition
 */
class FrameObserver : public IFrameObserver
{
public:
    FrameObserver(CameraPtr camera, OpenCvThread& openCvThread) :
        IFrameObserver(camera),
        m_openCvThread(openCvThread)
    {}

    void FrameReceived(const FramePtr frame)
    {
        assert(frame);

        VmbFrameStatusType status = VmbFrameStatusInvalid;
        VmbErrorType err = frame->GetReceiveStatus(status);
        if(err == VmbErrorSuccess && status == VmbFrameStatusComplete)
        {
            m_openCvThread.DisplayFrame(frame); // Pass complete frames to OpenCvThread
        }
        else
        {
            m_pCamera->QueueFrame(frame); // Re-enqueue incomplete frames directly without further processing
        }
    }

private:
    OpenCvThread& m_openCvThread;
};

/**
 * \brief Helper function to adjust the packet size for Allied Vision GigE cameras
 */
void GigEAdjustPacketSize(CameraPtr camera)
{
    StreamPtrVector streams;
    VmbErrorType err = camera->GetStreams(streams);

    if (err != VmbErrorSuccess || streams.empty())
    {
        throw std::runtime_error("Could not get stream modules, err=" + std::to_string(err));
    }

    FeaturePtr feature;
    err = streams[0]->GetFeatureByName("GVSPAdjustPacketSize", feature);

    if (err == VmbErrorSuccess)
    {
        err = feature->RunCommand();
        if (err == VmbErrorSuccess)
        {
            bool commandDone = false;
            do
            {
                if (feature->IsCommandDone(commandDone) != VmbErrorSuccess)
                {
                    break;
                }
            } while (commandDone == false);
        }
        else
        {
            std::cout << "Error while executing GVSPAdjustPacketSize, err=" + std::to_string(err) << std::endl;
        }
    }
}

AcquisitionHelper::AcquisitionHelper(const char* cameraId) :
    m_vmbSystem(VmbSystem::GetInstance())
{
    VmbErrorType err = m_vmbSystem.Startup();

    if (err != VmbErrorSuccess)
    {
        throw std::runtime_error("Could not start API, err=" + std::to_string(err));
    }

    CameraPtrVector cameras;
    err = m_vmbSystem.GetCameras(cameras);
    if (err != VmbErrorSuccess)
    {
        m_vmbSystem.Shutdown();
        throw std::runtime_error("Could not get cameras, err=" + std::to_string(err));
    }

    if (cameras.empty())
    {
        m_vmbSystem.Shutdown();
        throw std::runtime_error("No cameras found.");
    }

    if (cameraId != nullptr)
    {
        err = m_vmbSystem.GetCameraByID(cameraId, m_camera);
        if (err != VmbErrorSuccess)
        {
            m_vmbSystem.Shutdown();
            throw std::runtime_error("No camera found with ID=" + std::string(cameraId) + ", err = " + std::to_string(err));
        }
    }
    else
    {
        m_camera = cameras[0];
    }

    err = m_camera->Open(VmbAccessModeFull);
    if (err != VmbErrorSuccess)
    {
        m_vmbSystem.Shutdown();
        throw std::runtime_error("Could not open camera, err=" + std::to_string(err));
    }

    std::string name;
    if (m_camera->GetName(name) == VmbErrorSuccess)
    {
        std::cout << "Opened Camera " << name << std::endl;
    }

    try
    {
        GigEAdjustPacketSize(m_camera);
    }
    catch (std::runtime_error& e)
    {
        m_vmbSystem.Shutdown();
        throw e;
    }
}

AcquisitionHelper::AcquisitionHelper() :
    AcquisitionHelper(nullptr)
{
}

AcquisitionHelper::~AcquisitionHelper()
{
    try
    {
        VmbErrorType err = m_camera->StopContinuousImageAcquisition();
        if (err != VmbErrorSuccess)
        {
            throw std::runtime_error("Could not stop acquisition, err=" + std::to_string(err));
        }
    }
    catch(std::runtime_error& e)
    {
        std::cout << e.what() << std::endl;
    }
    catch (...)
    {
        // ignore
    }

    m_vmbSystem.Shutdown();
}

void AcquisitionHelper::Run()
{
    OpenCvThread openCvThread("VmbCPP - Press any key to stop the stream", m_camera);
    IFrameObserverPtr frameObserver(new FrameObserver(m_camera, openCvThread));

    VmbErrorType err = m_camera->StartContinuousImageAcquisition(5, frameObserver);
    if (err != VmbErrorSuccess)
    {
        throw std::runtime_error("Could not start acquisition, err=" + std::to_string(err));
    }
    openCvThread.Run();
}

} // namespace Examples
} // namespace VmbCPP
