
# VmbNET

The .NET API of the [Vimba X SDK](https://www.alliedvision.com).

Vimba X is a fully GenICam compliant SDK and the successor of Vimba. VmbNET is the .NET API that is
provided by this SDK. It provides access to the full functionality of Vimba X from .NET applications.

VmbNET can be used on Windows64, Linux64 and Linux ARM.

# Installation of VmbNET

## Requirements

To use VmbNET, a .NET runtime providing .NET Standard 2.0 is required.
These are .NET Framework 4.6.2 or above and .NET Core 2.0 or above.

## Installation with Visual Studio (Windows64 only)

After opening your application's project file with Visual Studio 2019 or Visual Studio 2022,
1. Open the NuGet Package Manager for the project by right-clicking it in Solution Explorer
and selecting `Manage NuGet Packages...`.
2. Click the cog wheel after `Package source:` to open the
package sources, and click the `+` icon. The `Name:` field can be whatever you like, but you will need it just now.
3. Enter into the `Source:` field either
    1. the following URL for the online NuGet packages: https://api.nuget.org/v3/index.json (if not already available by default) if installing from nuget.org or
    2. the path to the directory containing the VmbNET NuGet package file.
4. Close this window to return to the NuGet Package Manager.
5. Open the drop-down menu after `Package source:` and either select `All` or the `Name:` field value that you used
when adding the package source for VmbNET.
6. Select the `Browse` tab and search for `VmbNET`.
Click the VmbNET NuGet package that is displayed.
7. In the pane that appears, click `Install` to install the version shown.

## Installation from the command line

* Add to the package source either the URL for the online NuGet packages (if not already available by default) or the full path to the directory containing the `.nupkg` file
by executing

```C#
    dotnet nuget add source <https://api.nuget.org/v3/index.json-or-path-to-directory-containing-VmbNET-NuGet-package> -n <user-chosen-name-for-the-package-source>
```

* Install VmbNET to your application by changing directory to the location of your project file and executing

```C#
    dotnet add package VmbNET.<runtime-identifier>
```

where `<runtime-identifier>` is either `win-64`, `linux-x64` or `linux-arm64`, depending on the platform that your application should be built for.

* Then build your application by executing, in the same directory,

```C#
    dotnet build -c Release .
```

# Usage

Below is a minimal example demonstrating how to acquire frames for 2 seconds from the stream of the first camera found by VmbNET. It
highlights the general usage of VmbNET. More complete code examples can be found in the `Examples`
directory provided by the Vimba X installation.

```C#
   using VmbNET;

   class Program
   {
       static void Main()
       {
           using var vmb = IVmbSystem.Startup(); // API startup (loads transport layers)

           var cam = vmb.GetCameras()[0]; // Get the first available camera

           using var openCam = cam.Open(); // Open the camera

           openCam.Features.ExposureTime = 5000.0; // Set the exposure time value

           // Register an event handler for incoming frames
           openCam.FrameReceived += (s,e) =>
           {
               using var frame = e.Frame;
               Console.WriteLine($"Frame Received! ID={frame.Id}");
           }; // IDisposable: Frame is automatically requeued

           // Convenience function to start acquisition
           using var acquisition = openCam.StartFrameAcquisition();

           Thread.Sleep(2000);

       } // IDisposable: Stops acquisition, closes camera, shuts down Vimba X
   }
```

# Installation of the Feature Completion Extension for Visual Studio (Windows64 only)

The Feature Completion Extension assists with the development of applications using VmbNET in Visual Studio 2022 by providing Intellisense-like code completion for camera features,
as well as information about each feature, based on the Standard Feature Naming Convention (SFNC) provided by GenICam.
This extension is provided both on the Visual Studio Marketplace (see https://marketplace.visualstudio.com/items?itemName=AlliedVision.FeatureCompletion)
and as part of the Vimba X installation (as a file named `FeatureCompletion.vsix`).

## Installation with Visual Studio

After opening Visual Studio 2022,
1. Open the Extension Manager by clicking `Extensions` in the menu and selecting `Manage Extensions...`.
2. Select the `Browse` tab.
3. Start typing `Feature Completion` in the search field.
4. Once the `Feature Completion` item (with the Allied Vision logo) appears, select it and click its `Install` button.
5. Follow the instructions to complete the installation.

## Installation from the file

Doubl-click the `FeatureCompletion.vsix` in Windows Explorer and follow the instructions to complete the installation.
